#!/bin/sh
java -jar getdown-1.1.jar .